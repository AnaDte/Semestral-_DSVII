<?php

class TemaController {
    private $model;

    public function __construct($db) {
        $this->model = new TemaModel($db);
    }

    public function handleRequest() {
        $accion = $_GET['accion'] ?? 'listar';

        switch ($accion) {
            case 'crear':
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    $nombre = $_POST['nombreTema'];
                    $this->model->agregarTema($nombre);
                    header("Location: ?accion=listar");
                    exit;
                }
                include 'views/temas/crearTema.php';
                break;

            case 'editar':
                $id = $_GET['id'];
                $tema = $this->model->obtenerTemaPorId($id);
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    $nuevoNombre = $_POST['nombreTema'];
                    $this->model->actualizarTema($id, $nuevoNombre);
                    header("Location: ?accion=listar");
                    exit;
                }
                include 'views/temas/crearTema.php'; // reutilizado como editar
                break;

            case 'eliminar':
                $id = $_GET['id'];
                $this->model->eliminarTema($id);
                header("Location: ?accion=listar");
                exit;

            case 'listar':
            default:
                $temas = $this->model->obtenerTemas();
                include 'views/temas/listarTemas.php';
                break;
        }
    }
}
?>