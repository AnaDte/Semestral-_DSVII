<?php
require_once __DIR__ . '/../config/baseDatosConfig.php';
require_once __DIR__ . '/../controllers/JuegoController.php';

$db = new DB();
$controller = new JuegoController($db);

// Luego según la vista:
$controller->jugar();
include __DIR__ . '/../views/jugarView.php';
