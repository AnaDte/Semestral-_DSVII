<?php
require_once __DIR__ . '/../config/baseDatosConfig.php';
require_once __DIR__ . '/../controllers/GestionarPerfilController.php';

$db = new DB();
$controller = new GestionarPerfilController($db);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $controller->actualizarPerfil($_POST, $_FILES);
}

$usuarioId = $_SESSION['usuario'] ?? '';
$controller->mostrarPerfil($usuarioId);

include __DIR__ . '/../views/perfilJugadorView.php';