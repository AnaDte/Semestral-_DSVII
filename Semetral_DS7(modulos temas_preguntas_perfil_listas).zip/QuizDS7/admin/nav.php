<nav class="nav" id="nav">
    <ul>
        <li>
            <a href="index.php">
                <div class="icono" id="0">
                    <i class="fa-solid fa-user"></i>
                </div>
                Dashboard
            </a>
        </li>
        <li>
            <a href="nuevapregunta.php">
                <div class="icono" id="1">
                    <i class="fa-solid fa-question"></i>
                </div>
                Nueva Pregunta
            </a>
        </li>
        <li>
            <a href="listadopreguntas.php">
                <div class="icono" id="2">
                    <i class="fa-solid fa-list"></i>
                </div>
                Listado Preguntas
            </a>
        </li>
        <li>
            <a href="configuracion.php">
                <div class="icono" id="3">
                    <i class="fa-solid fa-gear"></i>
                </div>
                Configuración
            </a>
        </li>

        <li>
            <a href="adminUsuarios.php">
                <div class="icono" id="4">
                    <i class="fa-solid fa-users"></i>
                </div>
                Usuarios
            </a>
        </li>
        
        <li>
            <a href="Perfil.php">
                <div class="icono" id="4">
                    <i class="fa-solid fa-user-circle"></i>
                </div>
                Perfil
            </a>
        </li>
        
        <li>
            <a href="cerrar-sesion.php">
                <div class="icono" id="5">
                    <i class="fa-solid fa-right-from-bracket"></i>
                </div>
                Salir
            </a>
        </li>
    </ul>
</nav>