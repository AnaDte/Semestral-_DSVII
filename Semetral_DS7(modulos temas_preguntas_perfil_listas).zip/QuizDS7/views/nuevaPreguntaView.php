<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="stylesheet" href="../css/estiloAdmin.css">
    <title>Quiz Game</title>
</head>
<body>
    <div class="contenedor">
        <header>
            <h1>QUIZ GAME</h1>
        </header>
        <div class="contenedor-info">
            <?php include("../admin/nav.php") ?>
        <div class="panel">
            <h2>Complete la Pregunta</h2>
            <hr>
            <section id="nuevaPregunta">
                <form method="get">
                    <div class="fila">
                        <label for="">Tema: </label>
                        <select name="tema" id="tema">
                            <?php foreach ($controller->temas as $row) : ?> <!--Recorrer los temas -->
                            <option value="<?php echo $row['id'] ?>">
                            <?php echo $row['nombre'] ?>
                            </option>
                            <?php endforeach ?>
                        </select>
                        <span class="agregarTema" onclick="agregarTema()">
                        <i class="fa-solid fa-circle-plus"></i></span>
                    </div>
                    <!-- SELECTOR NUEVO AHHHHHHHH -->
                        <div class="fila">
                            <label for="">Dificultad:</label>
                            <select name="dificultadN" id="dificultadN" required>
                            <option value="Basico">Basico</option>
                            <option value="Intermedio">Intermedio</option>
                            <option value="Experto">Experto</option>
                            </select>
                        </div>
                    <!-- ********************************************** -->
                        
                        <div class="fila">
                            <label for="">Tipo de pregunta: </label>
                        <select name="tipo_pregunta" id="tipo_pregunta" onchange="mostrarOpciones()">
                        <option value="opcion_multiple">Opción múltiple</option>
                        <option value="cierto_falso">Cierto/Falso</option>
                                    
                        </select>
                        </div>
                        <div class="fila">
                            <label for="">Pregunta:</label>
                            <textarea name="pregunta" id="" cols="30" rows="10" required></textarea>
                        </div>
                        <!-- OPCIONES PARA PREGUNTAS DE OPCIÓN MÚLTIPLE -->
<div id="opciones_multiple" class="fila">
    <div class="opcion">
        <label for="">Opción A</label>
        <input type="text" name="opcion_a" id="opcion_a">
    </div>
    <div class="opcion">
        <label for="">Opción B</label>
        <input type="text" name="opcion_b" id="opcion_b">
    </div>
    <div class="opcion">
        <label for="">Opción C</label>
        <input type="text" name="opcion_c" id="opcion_c">
    </div>
    <div class="opcion">
        <label for="">Correcta</label>
        <select name="correcta" id="correcta">
            <option value="A">A</option>
            <option value="B">B</option>
            <option value="C">C</option>
        </select>
    </div>
</div>

<!-- OPCIONES PARA PREGUNTAS DE CIERTO/FALSO -->
<div id="opciones_cierto_falso" class="opciones" style="display: none;">
    <div class="opcion">
        <label for="">Respuesta</label>
        <select name="respuesta_cf" id="respuesta_cf">
            <option value="Cierto">Cierto</option>
            <option value="Falso">Falso</option>
        </select>
    </div>
</div>
                        <hr>
                    <input type="submit" value="Guardar Pregunta" name="guardar" class="btn-guardar">
                </form>
                <?php if (isset($_GET['guardar']) && isset($controller->mensaje)) : ?>
                    <span><?php echo $controller->mensaje; ?></span>
                <?php endif; ?>
            </section>
        </div>
    </div>
    </div>
    <!-- Ventana Modal para nuevo Tema -->
    <div id="modalTema" class="modal">
        <!-- Modal content -->
        <div class="modal-content">
            <span class="close" onclick="cerrarTema()">&times;</span>
            <form action = "" method="post"> 
                <label for="">Agregar Nuevo Tema</label>
                <input type="text"   name="nombreTema" required>
                <input type="submit" name="nuevoTema" value="Guardar Tema" class="btn">
            </form>
        </div>
    </div>
<!---php echo $_SERVER['PHP_SELF'] form action ="aquiiii" --> 
    <script src="script.js"></script>
    <script>paginaActiva(1);</script>


    <!-- **************************************************** -->
    <script>
function mostrarOpciones() {
    const tipo = document.getElementById("tipo_pregunta").value;
    const opcionC = document.querySelector("input[name='opcion_c']").parentElement;
    const selectCorrecta = document.querySelector("select[name='correcta']");

    if (tipo === "cierto_falso") {
        // Oculta opción C
        opcionC.style.display = "none";

        // Coloca valores fijos
        document.querySelector("input[name='opcion_a']").value = "Cierto";
        document.querySelector("input[name='opcion_b']").value = "Falso";

        // Solo A y B como correctas
        selectCorrecta.innerHTML = `
            <option value="A">A (Cierto)</option>
            <option value="B">B (Falso)</option>
        `;
    } else {
        
        document.querySelector("input[name='opcion_a']").value = "";
        document.querySelector("input[name='opcion_b']").value = "";
        document.querySelector("input[name='opcion_c']").value = "";

        selectCorrecta.innerHTML = `
            <option value="A">A</option>
            <option value="B">B</option>
            <option value="C">C</option>
        `;
    }
}

// Ejecutar cuando cambie el tipo de pregunta
document.addEventListener("DOMContentLoaded", () => {
    mostrarOpciones();
    document.getElementById("tipo_pregunta").addEventListener("change", mostrarOpciones);
});
</script>

</body>
</html>