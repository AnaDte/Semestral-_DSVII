<?php
$temas = [];
foreach ($controller->temas as $t) {
    $temas[$t['id']] = $t['nombre'];
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer"/>
    <link rel="stylesheet" href="../css/estiloAdmin.css">
    <title>Quiz Game</title>
</head>
<body>
    <div class="contenedor">
        <header>
            <h1>QUIZ GAME</h1>
        </header>
        <div class="contenedor-info">
            <?php include("nav.php") ?>
            <div class="panel">
                <h2>Listado de Preguntas</h2>
                <hr>
                <form method="GET" style="margin-bottom: 20px;">
                    <label for="tema">Tema:</label>
                    <select name="tema" id="tema">
                        <option value="">Todos</option>
                       <?php foreach ($controller->temas as $t): ?>
                        <option value="<?= $t['id'] ?>" <?= ($controller->tema == $t['id']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($t['nombre']) ?>
                        </option>
                    <?php endforeach; ?>
                    </select>

                    <label for="dificultad">Dificultad:</label>
                    <select name="dificultad" id="dificultad">
                        <option value="">Todas</option>
                        <option value="Basico" <?= ($controller->dificultad == 'Basico') ? 'selected' : '' ?>>Básico</option>
                        <option value="Intermedio" <?= ($controller->dificultad == 'Intermedio') ? 'selected' : '' ?>>Intermedio</option>
                        <option value="Experto" <?= ($controller->dificultad == 'Experto') ? 'selected' : '' ?>>Experto</option>
                    </select>
                    <button type="submit" class="btn-filtro">Filtrar</button>
                </form>

                <section id="listadoPreguntas">
                <?php foreach ($controller->resultado_preguntas as $row): ?>
                    <div class="contenedor-pregunta">
                        <header>
                            <span class="tema"><?= $temas[$row['tema']] ?? 'Sin tema' ?></span>
                            <div class="opciones">
                                <i class="fa-solid fa-pen-to-square" onclick="editarPregunta(<?php echo $row['id']?>)"></i>
                                <i class="fa-solid fa-trash" onclick="abrirModalEliminar(<?php echo $row['id']?>)"></i>
                            </div>
                        </header>
                        <p class="pregunta"><?php echo $row['pregunta']?></p>
                        <div class="opcion">
                            <div class="caja <?php if($row['correcta']=='A'){ echo 'pintarVerde';}?>">
                                A
                            </div>
                            <span class="texto"><?php echo $row['opcion_a']?></span>
                        </div>
                        <div class="opcion">
                            <span class="caja <?php if($row['correcta']=='B'){ echo 'pintarVerde';}?>">B</span>
                            <span class="texto"><?php echo $row['opcion_b']?></span>
                        </div>
                        <div class="opcion">
                            <span class="caja <?php if($row['correcta']=='C'){ echo 'pintarVerde';}?>">C</span>
                            <span class="texto"><?php echo $row['opcion_c']?></span>
                        </div>
                    </div>
                <?php endforeach; ?>
                </section>
            </div>
        </div>
    </div>
    <!-- The Modal para la eliminación de una Pregunta -->
    <div id="modalPregunta" class="modal">
        <div class="modal-content">
            <p>¿Esta seguro que desea eliminar la Pregunta?</p>
            <button onclick="eliminarPregunta()" class="btn">Si</button>
            <button onclick="cerrarEliminar()" class="btn">Cancelar</button>
        </div>
    </div>
    <script src="script.js"></script>
    <script>paginaActiva(2);</script>   
</body>
</html>