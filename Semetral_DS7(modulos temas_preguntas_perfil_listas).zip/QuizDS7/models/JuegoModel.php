<?php
class JuegoModel {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function obtenerConfiguracion() {
        $sql = "SELECT * FROM config WHERE id='1'";
        $stmt = $this->db->getConexion()->prepare($sql);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}