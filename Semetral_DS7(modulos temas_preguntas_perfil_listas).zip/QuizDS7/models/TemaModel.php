<?php
class TemaModel {
    private $db; // Instancia de DB

    public function __construct($db) {
        $this->db = $db;
    }

    public function obtenerTodos() {
        $sql = "SELECT * FROM temas";
        $stmt = $this->db->getConexion()->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function agregarTema($nombre) {
    // Verificar si ya existe el tema
    $sql = "SELECT COUNT(*) FROM temas WHERE nombre = :nombre";
    $stmt = $this->db->getConexion()->prepare($sql);
    $stmt->bindValue(':nombre', $nombre);
    $stmt->execute();
    if ($stmt->fetchColumn() > 0) {
        return false; // Ya existe, no lo inserta
    }

    $data = ['nombre' => $nombre];
    return $this->db->insertSeguro('temas', $data);
}

    public function obtenerNombreTema($id) {
       $sql = "SELECT nombre FROM temas WHERE id = :id";
        $stmt = $this->db->getConexion()->prepare($sql);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? $row['nombre'] : '';
    }

    public function obtenerCategorias() {
       $sql = "SELECT id, nombre FROM temas";
        $stmt = $this->db->getConexion()->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>