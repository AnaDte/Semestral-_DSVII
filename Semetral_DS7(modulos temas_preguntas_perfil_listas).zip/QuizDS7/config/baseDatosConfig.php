<?php //config/baseDatosConfig.php

class DB {

private $conexion;           
private $debug = false;       

public function __construct() {
$sql_host = "localhost";
$sql_name = "trivia"; // Nombre de la base de datos
$sql_user = "admin";
$sql_pass = "root2514";
$charset = 'utf8mb4';

$dsn = "mysql:host=$sql_host;dbname=$sql_name;charset=utf8mb4";

	try {
		$this->conexion = new PDO($dsn, $sql_user, $sql_pass);
		$this->conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		if ($this->debug) {
		echo "Conexión exitosa a la base de datos<br>";
		}
	} catch (PDOException $e) {
		echo "Error de conexión: " . $e->getMessage();
		exit;
		}
   	}

    public function getConexion() {
    return $this->conexion;
    }

    public function insertSeguro($tb_name, $data) {
        $columns = implode(", ", array_keys($data));
        $placeholders = ":" . implode(", :", array_keys($data));
        $sql = "INSERT INTO $tb_name ($columns) VALUES ($placeholders)";
        try { 
            $stmt = $this->conexion->prepare($sql);
            foreach ($data as $key => $value) { 
                $stmt->bindValue(":$key", $value);
            }
            $stmt->execute();
            return true;
        } catch (PDOException $e) {
            echo "Error en INSERT: " . $e->getMessage();
            return false;
        }
    }

    public function selectSeguroMultiple($tabla, $columnas = ['*'], $camposBusqueda = [], $valor = "") {
        $cols = implode(", ", $columnas); // convertir un arreglo en una cadena de texto
        $sql = "SELECT $cols FROM $tabla";

        // Arma condiciones WHERE con varios campos usando OR
        if (!empty($camposBusqueda) && !empty($valor)) {
            $whereParts = [];
            foreach ($camposBusqueda as $campo) {
                $whereParts[] = "$campo LIKE :valor";
            }
            $sql .= " WHERE " . implode(" OR ", $whereParts);
        }
        // Orden descendente por ID
        $sql .= " ORDER BY id DESC";
    
        try {
            $stmt = $this->conexion->prepare($sql);
            if (!empty($camposBusqueda) && !empty($valor)) {// Vincula el valor si hay búsqueda
                $stmt->bindValue(":valor", "%$valor%");
            }
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            echo "Error en BUSQUEDA múltiple: " . $e->getMessage();
            return false;
        }
        
    }
    
	public function updateSeguro($tabla, $data, $condiciones) {
        $set = [];
        foreach ($data as $key => $value) {
            $set[] = "$key = :$key";
        }
        $setSQL = implode(", ", $set);
        $where = [];
        foreach ($condiciones as $key => $value) {
            $where[] = "$key = :cond_$key";
        }
        $whereSQL = implode(" AND ", $where);
        $sql = "UPDATE $tabla SET $setSQL WHERE $whereSQL";
        try {
            $stmt = $this->conexion->prepare($sql);
            foreach ($data as $key => $value) {
                $stmt->bindValue(":$key", $value);
            }
            foreach ($condiciones as $key => $value) {
                $stmt->bindValue(":cond_$key", $value);
            }
            return $stmt->execute();
        } catch (PDOException $e) {
            echo "Error en UPDATE: " . $e->getMessage();
            return false;
        }
    }

    public function obtenerUsuarioPorCorreo($correo) {
        $sql = "SELECT * FROM usuario WHERE correo = :correo LIMIT 1";
        try {
            $stmt = $this->conexion->prepare($sql);
            $stmt->bindValue(':correo', $correo);
            $stmt->execute();
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            if ($this->debug) echo "Error en obtenerUsuarioPorCorreo: " . $e->getMessage();
            return null;
        }
    }
    
}
